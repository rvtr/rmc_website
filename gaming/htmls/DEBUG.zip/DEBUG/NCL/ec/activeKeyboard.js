function ActiveKeyboard( type, title, field )
{
    var kong_ = new Kong;
	kong_.KbdActive( type, title, field );
}