//----------------------------------------
//-- define : SE No. (refer to sound_data.sadl)

/* #### 20080628 #### Changed SE No. */

var TWL_SHOP_SE_ONMOUSEDOWN   =  20;
var TWL_SHOP_SE_ONCLICK       =  19;
var TWL_SHOP_SE_TRANSIT       =  17;

